export const botConfig = {
  telegramBot: {
    username: 'ddc_support_bot',
    baseUrl: 'https://t.me'
  }
};
